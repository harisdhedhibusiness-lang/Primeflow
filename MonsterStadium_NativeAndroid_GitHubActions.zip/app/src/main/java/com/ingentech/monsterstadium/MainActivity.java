
package com.ingentech.monsterstadium;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.text.method.ScrollingMovementMethod;
import java.util.*;

public class MainActivity extends Activity {
    final int BG = Color.rgb(11,16,32);
    final int PANEL = Color.rgb(24,32,58);
    final int PANEL2 = Color.rgb(31,42,76);
    final int GOLD = Color.rgb(245,200,91);
    final int TEXT = Color.rgb(244,247,255);
    final int MUTED = Color.rgb(154,168,199);

    LinearLayout root, nav, content;
    SharedPreferences prefs;
    ArrayList<Creature> dex = new ArrayList<>();
    ArrayList<String> team = new ArrayList<>();
    boolean owner = false;
    String starter = "";
    Creature enemy = null;
    int playerHp = 0, enemyHp = 0;
    boolean boosted = false;
    int potions = 3, boosts = 2, coins = 250;
    TextView logView;

    static class Creature {
        int id, stage, phase, hp, atk, def, speed, spirit, evolveLevel;
        String name, type, role, line, rarity, evolvesTo;
        boolean starter, locked;
        String[] moves, weakTo, strongAgainst;
        Creature(int id, String name, String type, String role, int stage, String line, int phase,
                 String rarity, boolean starter, boolean locked, String evolvesTo, int evolveLevel,
                 int hp, int atk, int def, int speed, int spirit, String[] moves, String[] weakTo, String[] strongAgainst) {
            this.id=id; this.name=name; this.type=type; this.role=role; this.stage=stage; this.line=line;
            this.phase=phase; this.rarity=rarity; this.starter=starter; this.locked=locked; this.evolvesTo=evolvesTo;
            this.evolveLevel=evolveLevel; this.hp=hp; this.atk=atk; this.def=def; this.speed=speed; this.spirit=spirit;
            this.moves=moves; this.weakTo=weakTo; this.strongAgainst=strongAgainst;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("monster_stadium_save", MODE_PRIVATE);
        generateDex();
        loadState();

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView title = tv("Monster Stadium", 28, TEXT, true);
        title.setPadding(dp(16), dp(16), dp(16), dp(2));
        root.addView(title);

        TextView sub = tv("Founder Build · Native Android · 1,024 Original Champions", 12, GOLD, true);
        sub.setPadding(dp(16), 0, dp(16), dp(8));
        root.addView(sub);

        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(4), dp(8), dp(8));
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.addView(nav);
        root.addView(hsv);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(20));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        addNav("Home", () -> screenHome());
        addNav("Starter", () -> screenStarter());
        addNav("Battle", () -> screenBattle());
        addNav("Team", () -> screenTeam());
        addNav("Dex", () -> screenDex(""));
        addNav("Items", () -> screenItems());
        addNav("Owner", () -> ownerPrompt());

        screenHome();
    }

    void loadState() {
        owner = prefs.getBoolean("owner", false);
        starter = prefs.getString("starter", "");
        String teamStr = prefs.getString("team", "");
        team.clear();
        if (!teamStr.isEmpty()) team.addAll(Arrays.asList(teamStr.split(",")));
        potions = prefs.getInt("potions", 3);
        boosts = prefs.getInt("boosts", 2);
        coins = prefs.getInt("coins", 250);
    }

    void saveState() {
        prefs.edit()
                .putBoolean("owner", owner)
                .putString("starter", starter)
                .putString("team", join(team, ","))
                .putInt("potions", potions)
                .putInt("boosts", boosts)
                .putInt("coins", coins)
                .apply();
    }

    void addNav(String label, final Runnable r) {
        Button b = btn(label);
        b.setOnClickListener(v -> r.run());
        nav.addView(b);
    }

    void clear() { content.removeAllViews(); }

    TextView tv(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(dp(2), 1.0f);
        return t;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(TEXT);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setBackgroundColor(PANEL2);
        b.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44));
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        return b;
    }

    TextView cardTitle(String s) {
        TextView t = tv(s, 20, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawableBg(c, PANEL, dp(18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        c.setLayoutParams(lp);
        return c;
    }

    void GradientDrawableBg(View v, int color, int radius) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        g.setStroke(dp(1), Color.rgb(42,53,88));
        v.setBackground(g);
    }

    void screenHome() {
        clear();
        ArenaView av = new ArenaView(this);
        content.addView(av, new LinearLayout.LayoutParams(-1, dp(220)));

        LinearLayout c = card();
        c.addView(cardTitle("Build your team. Win the arena."));
        c.addView(tv("This native Android prototype includes 1,024 original creatures, starter selection, phase-locked expansion content, turn-based battle logic, XP, leveling, evolution checks, items, and owner unlock mode.", 15, MUTED, false));
        Button start = btn(starter.isEmpty() ? "Choose Starter" : "Enter Arena");
        start.setOnClickListener(v -> { if (starter.isEmpty()) screenStarter(); else screenBattle(); });
        c.addView(start);
        content.addView(c);

        LinearLayout phases = card();
        phases.addView(cardTitle("Expansion Plan"));
        phases.addView(tv("Phase 1: Launch Dex unlocked\nPhase 2+: Future Champions locked for release previews\nOwner Mode: unlocks all content for testing", 15, MUTED, false));
        content.addView(phases);
    }

    void screenStarter() {
        clear();
        content.addView(cardTitle("Choose Your First Champion"));
        content.addView(tv("Pick one starter. Owner mode can reset/unlock everything.", 14, MUTED, false));
        for (Creature m : dex) {
            if (m.starter && m.stage == 1) {
                LinearLayout c = creatureCard(m, true);
                Button pick = btn("Choose " + m.name);
                pick.setOnClickListener(v -> chooseStarter(m));
                c.addView(pick);
                content.addView(c);
            }
        }
    }

    void chooseStarter(Creature m) {
        if (!starter.isEmpty() && !owner) { alert("Starter already chosen. Owner code can reset."); return; }
        starter = m.name;
        team.clear();
        team.add(m.name);
        prefs.edit().putInt("level_" + m.name, 5).putInt("xp_" + m.name, 0).apply();
        saveState();
        alert(m.name + " joined your team.");
        newEnemy();
        screenBattle();
    }

    void screenBattle() {
        clear();
        content.addView(cardTitle("Stadium Battle"));
        if (team.isEmpty()) {
            content.addView(tv("Choose a starter first.", 16, MUTED, false));
            Button b = btn("Choose Starter");
            b.setOnClickListener(v -> screenStarter());
            content.addView(b);
            return;
        }
        if (enemy == null) newEnemy();

        BattleView bv = new BattleView(this);
        content.addView(bv, new LinearLayout.LayoutParams(-1, dp(220)));

        Creature p = creature(team.get(0));
        LinearLayout status = card();
        status.addView(tv(p.name + " Lv." + level(p.name) + "  HP " + playerHp + "/" + maxHp(p), 16, TEXT, true));
        status.addView(tv("Enemy: " + enemy.name + "  HP " + enemyHp + "/" + maxHp(enemy), 16, TEXT, true));
        content.addView(status);

        LinearLayout moves = card();
        moves.addView(cardTitle("Moves"));
        for (String mv : p.moves) {
            Button b = btn(mv);
            b.setOnClickListener(v -> attack(mv));
            moves.addView(b);
        }
        content.addView(moves);

        LinearLayout tools = card();
        tools.addView(cardTitle("Items"));
        Button pot = btn("Use Potion (" + potions + ")");
        pot.setOnClickListener(v -> usePotion());
        Button boost = btn("Use Boost (" + boosts + ")");
        boost.setOnClickListener(v -> useBoost());
        Button opp = btn("New Opponent");
        opp.setOnClickListener(v -> { newEnemy(); screenBattle(); });
        tools.addView(pot); tools.addView(boost); tools.addView(opp);
        content.addView(tools);

        logView = tv("", 13, TEXT, false);
        logView.setMinLines(5);
        logView.setMovementMethod(new ScrollingMovementMethod());
        LinearLayout lcard = card();
        lcard.addView(cardTitle("Battle Log"));
        lcard.addView(logView);
        content.addView(lcard);
        log("Ready.");
    }

    void screenTeam() {
        clear();
        content.addView(cardTitle("Your Team"));
        if (team.isEmpty()) {
            content.addView(tv("No team yet. Choose a starter.", 15, MUTED, false));
            return;
        }
        for (String n : team) {
            Creature m = creature(n);
            LinearLayout c = creatureCard(m, false);
            c.addView(tv("Level: " + level(n) + " · XP: " + xp(n) + "/" + (level(n)*25), 14, MUTED, false));
            c.addView(tv(m.evolvesTo == null ? "Final form" : "Evolves to " + m.evolvesTo + " at Lv." + m.evolveLevel, 14, MUTED, false));
            Button evo = btn("Check Evolution");
            evo.setOnClickListener(v -> tryEvolve(n));
            c.addView(evo);
            content.addView(c);
        }
    }

    void screenDex(String query) {
        clear();
        content.addView(cardTitle("Champion Dex"));
        content.addView(tv("1,024 original creatures. Phase 2+ are locked Future Champions unless Owner Mode is enabled.", 14, MUTED, false));
        EditText search = new EditText(this);
        search.setHint("Search name/type/role");
        search.setTextColor(TEXT);
        search.setHintTextColor(MUTED);
        search.setSingleLine(true);
        search.setText(query);
        GradientDrawableBg(search, Color.rgb(16,23,42), dp(12));
        content.addView(search, new LinearLayout.LayoutParams(-1, dp(52)));
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(Editable e){ renderDexList(e.toString()); }
        });
        renderDexList(query);
    }

    void renderDexList(String q) {
        while (content.getChildCount() > 3) content.removeViewAt(3);
        String lower = q == null ? "" : q.toLowerCase();
        int shown = 0;
        for (Creature m : dex) {
            if (!lower.isEmpty() && !(m.name.toLowerCase().contains(lower) || m.type.toLowerCase().contains(lower) || m.role.toLowerCase().contains(lower))) continue;
            if (shown >= 80) break;
            LinearLayout c = creatureCard(m, false);
            boolean locked = !isUnlocked(m);
            c.setAlpha(locked ? 0.55f : 1f);
            c.setOnClickListener(v -> {
                if (!isUnlocked(m)) alert("Locked Future Champion. Phase " + m.phase + " releases later. Owner Mode can preview all.");
                else alert(detail(m));
            });
            content.addView(c);
            shown++;
        }
        if (shown == 0) content.addView(tv("No results.", 15, MUTED, false));
    }

    void screenItems() {
        clear();
        content.addView(cardTitle("Items & Unlocks"));
        LinearLayout c = card();
        c.addView(tv("Coins: " + coins + "\nPotions: " + potions + "\nBoosts: " + boosts + "\nOwner Mode: " + (owner ? "ON" : "OFF"), 16, TEXT, true));
        Button p = btn("Add Potion - 50 coins");
        p.setOnClickListener(v -> { buy("potion"); screenItems(); });
        Button b = btn("Add Boost - 50 coins");
        b.setOnClickListener(v -> { buy("boost"); screenItems(); });
        Button pay = btn("Expansion Pass Stub");
        pay.setOnClickListener(v -> alert(owner ? "Owner bypass active." : "Payment hook placeholder. Wire this to Google Play Billing or RevenueCat in production."));
        c.addView(p); c.addView(b); c.addView(pay);
        content.addView(c);
    }

    LinearLayout creatureCard(Creature m, boolean full) {
        LinearLayout c = card();
        CreatureIcon icon = new CreatureIcon(this, m.type);
        c.addView(icon, new LinearLayout.LayoutParams(dp(86), dp(86)));
        c.addView(tv("#" + m.id + " " + (isUnlocked(m) ? m.name : "Locked"), 20, TEXT, true));
        c.addView(tv(m.type + " · " + m.role + " · Phase " + m.phase + " · " + m.rarity, 14, GOLD, true));
        String evo = m.line.replace("-", " → ");
        c.addView(tv(isUnlocked(m) ? evo : "Future Champion · Coming Soon", 14, MUTED, false));
        if (full && isUnlocked(m)) c.addView(tv(detail(m), 13, MUTED, false));
        return c;
    }

    String detail(Creature m) {
        return "Type: " + m.type +
                "\nRole: " + m.role +
                "\nEvolution: " + m.line.replace("-", " → ") +
                "\nStats: HP " + m.hp + " · ATK " + m.atk + " · DEF " + m.def + " · SPD " + m.speed +
                "\nMoves: " + join(Arrays.asList(m.moves), ", ") +
                "\nStrong: " + join(Arrays.asList(m.strongAgainst), ", ") +
                "\nWeak: " + join(Arrays.asList(m.weakTo), ", ");
    }

    void newEnemy() {
        ArrayList<Creature> pool = new ArrayList<>();
        for (Creature m : dex) if (m.phase == 1 && !m.starter && m.stage <= 2) pool.add(m);
        enemy = pool.get(new Random().nextInt(pool.size()));
        Creature p = team.isEmpty() ? null : creature(team.get(0));
        if (p != null) playerHp = maxHp(p);
        enemyHp = maxHp(enemy);
        boosted = false;
    }

    int maxHp(Creature m) { return m.hp + level(m.name) * 6; }
    int level(String name) { return prefs.getInt("level_" + name, 5); }
    int xp(String name) { return prefs.getInt("xp_" + name, 0); }

    void attack(String move) {
        Creature p = creature(team.get(0));
        double mult = multiplier(p.type, enemy.type);
        int dmg = Math.max(6, (int)((18 + p.atk * .55 - enemy.def * .22 + new Random().nextInt(11)) * mult * (boosted ? 1.25 : 1)));
        enemyHp -= dmg;
        boosted = false;
        log(p.name + " used " + move + ". " + (mult > 1 ? "Strong hit. " : mult < 1 ? "Resisted. " : "") + dmg + " damage.");
        if (enemyHp <= 0) { winBattle(); screenBattle(); return; }
        enemyTurn();
        screenBattle();
    }

    void enemyTurn() {
        Creature p = creature(team.get(0));
        double mult = multiplier(enemy.type, p.type);
        int dmg = Math.max(5, (int)((16 + enemy.atk * .45 - p.def * .20 + new Random().nextInt(9)) * mult));
        playerHp -= dmg;
        if (playerHp <= 0) playerHp = 1;
    }

    void winBattle() {
        Creature p = creature(team.get(0));
        int gained = 35 + new Random().nextInt(25);
        int newXp = xp(p.name) + gained;
        int lvl = level(p.name);
        SharedPreferences.Editor e = prefs.edit();
        if (newXp >= lvl * 25) {
            newXp -= lvl * 25;
            lvl++;
            e.putInt("level_" + p.name, lvl);
            alert(p.name + " won and leveled up to " + lvl + ".");
        } else {
            alert(p.name + " won and gained " + gained + " XP.");
        }
        e.putInt("xp_" + p.name, newXp).apply();
        coins += 25;
        saveState();
        newEnemy();
    }

    void usePotion() {
        if (potions <= 0 && !owner) { alert("No potions left."); return; }
        if (!owner) potions--;
        Creature p = creature(team.get(0));
        playerHp = Math.min(maxHp(p), playerHp + 35);
        saveState();
        screenBattle();
    }

    void useBoost() {
        if (boosts <= 0 && !owner) { alert("No boosts left."); return; }
        if (!owner) boosts--;
        boosted = true;
        saveState();
        alert("Boost armed. Next attack is stronger.");
        screenBattle();
    }

    void buy(String item) {
        if (!owner && coins < 50) { alert("Not enough coins."); return; }
        if (!owner) coins -= 50;
        if (item.equals("potion")) potions++;
        else boosts++;
        saveState();
    }

    void tryEvolve(String n) {
        Creature m = creature(n);
        if (m.evolvesTo == null) { alert(m.name + " is already final form."); return; }
        if (level(n) < m.evolveLevel && !owner) { alert(m.name + " needs Lv." + m.evolveLevel + "."); return; }
        int i = team.indexOf(n);
        if (i >= 0) team.set(i, m.evolvesTo);
        prefs.edit()
                .putInt("level_" + m.evolvesTo, Math.max(level(n), m.evolveLevel))
                .putInt("xp_" + m.evolvesTo, xp(n))
                .remove("level_" + n)
                .remove("xp_" + n)
                .apply();
        saveState();
        alert(n + " evolved into " + m.evolvesTo + ".");
        screenTeam();
    }

    double multiplier(String atk, String def) {
        String[] strong = strongAgainst(atk);
        String[] weak = weakAgainst(atk);
        for (String s : strong) if (s.equals(def)) return 1.35;
        for (String s : weak) if (s.equals(def)) return .72;
        return 1.0;
    }

    void ownerPrompt() {
        final EditText input = new EditText(this);
        input.setHint("Owner code");
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        new android.app.AlertDialog.Builder(this)
                .setTitle("Owner Mode")
                .setView(input)
                .setPositiveButton("Unlock", (d,w) -> {
                    String code = input.getText().toString().trim();
                    if (code.equals("INGEN-OWNER")) { owner = true; saveState(); alert("Owner mode enabled. All phases preview unlocked."); }
                    else if (code.equals("RESET")) { prefs.edit().clear().apply(); loadState(); alert("Save reset."); screenHome(); }
                    else alert("Invalid code.");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    boolean isUnlocked(Creature m) { return owner || m.phase == 1; }
    Creature creature(String name) { for (Creature m : dex) if (m.name.equals(name)) return m; return dex.get(0); }

    void alert(String msg) {
        new android.app.AlertDialog.Builder(this)
                .setTitle("Monster Stadium")
                .setMessage(msg)
                .setPositiveButton("OK", null)
                .show();
    }

    void log(String msg) { if (logView != null) logView.setText(msg + "\n" + logView.getText()); }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    String join(List<String> arr, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<arr.size();i++){ if(i>0)sb.append(sep); sb.append(arr.get(i)); }
        return sb.toString();
    }

    String[] movesFor(String type) {
        switch(type){
            case "Electric": return new String[]{"Bijli Chamaat","Current Snap","Voltage Rush","Garaj Break"};
            case "Fire": return new String[]{"Angaar Bite","Dhuaan Veil","Mirchi Burn","Flare Rush"};
            case "Water": return new String[]{"Paani Guard","Lehar Cut","Deep Pull","Flood Slam"};
            case "Grass": return new String[]{"Neem Sting","Root Lock","Kikar Spike","Dust Bind"};
            case "Earth": return new String[]{"Dust Bind","Stone Rush","Quake Tap","Ground Lock"};
            case "Air": return new String[]{"Hawa Cut","Sky Drop","Gust Rush","Wing Snap"};
            case "Steel": return new String[]{"Iron Bash","Chrome Guard","Gear Bite","Steel Rush"};
            case "Dark": return new String[]{"Night Swipe","Shadow Feint","Blackout Bite","Vanish Cut"};
            case "Light": return new String[]{"Noor Beam","Flash Guard","Radiant Push","Halo Strike"};
            case "Psychic": return new String[]{"Mindbend","Nazar Lock","Focus Break","Pulse Read"};
            case "Ice": return new String[]{"Frost Tap","Baraf Claw","Cold Guard","Glacier Hit"};
            case "Poison": return new String[]{"Zehr Jab","Toxic Veil","Venom Lock","Acid Snap"};
            case "Fighting": return new String[]{"Street Jab","Guard Break","Knuckle Rush","Heavy Kick"};
            case "Rock": return new String[]{"Stone Guard","Boulder Tap","Granite Slam","Rock Lock"};
            default: return new String[]{"Dhuaan Cover","Ash Flick","Smog Bind","Haze Step"};
        }
    }
    String[] weakAgainst(String type) {
        switch(type){
            case "Electric": return new String[]{"Earth","Rock"};
            case "Fire": return new String[]{"Water","Rock"};
            case "Water": return new String[]{"Electric","Grass"};
            case "Grass": return new String[]{"Fire","Ice"};
            case "Earth": return new String[]{"Water","Grass"};
            case "Air": return new String[]{"Electric","Ice"};
            case "Steel": return new String[]{"Fire","Earth"};
            case "Dark": return new String[]{"Light","Fighting"};
            case "Light": return new String[]{"Dark","Smoke"};
            case "Psychic": return new String[]{"Dark","Poison"};
            case "Ice": return new String[]{"Fire","Steel"};
            case "Poison": return new String[]{"Earth","Psychic"};
            case "Fighting": return new String[]{"Psychic","Air"};
            case "Rock": return new String[]{"Water","Grass"};
            default: return new String[]{"Air","Light"};
        }
    }
    String[] strongAgainst(String type) {
        switch(type){
            case "Electric": return new String[]{"Water","Air","Steel"};
            case "Fire": return new String[]{"Grass","Ice","Steel"};
            case "Water": return new String[]{"Fire","Rock","Earth"};
            case "Grass": return new String[]{"Water","Earth","Rock"};
            case "Earth": return new String[]{"Electric","Steel","Poison"};
            case "Air": return new String[]{"Grass","Smoke","Fighting"};
            case "Steel": return new String[]{"Rock","Ice","Light"};
            case "Dark": return new String[]{"Psychic","Light"};
            case "Light": return new String[]{"Dark","Smoke"};
            case "Psychic": return new String[]{"Fighting","Poison"};
            case "Ice": return new String[]{"Grass","Air","Water"};
            case "Poison": return new String[]{"Grass","Psychic"};
            case "Fighting": return new String[]{"Rock","Steel","Dark"};
            case "Rock": return new String[]{"Fire","Air","Electric"};
            default: return new String[]{"Light","Grass"};
        }
    }

    void generateDex() {
        dex.clear();
        add("Tayz","Electric","Speed Attacker",1,"Tayz-Voltra-Ravolt",1,"Rare",true,false,"Voltra",16,68,66,42,72,48);
        add("Voltra","Electric","Speed Attacker",2,"Tayz-Voltra-Ravolt",1,"Rare",false,false,"Ravolt",36,91,84,59,94,66);
        add("Ravolt","Electric","Speed Attacker",3,"Tayz-Voltra-Ravolt",1,"Epic",false,false,null,0,125,111,78,126,89);

        add("Tiko","Fire","Burst Attacker",1,"Tiko-Cindar-Flarex",1,"Rare",true,false,"Cindar",16,65,72,40,56,48);
        add("Cindar","Fire","Burst Attacker",2,"Tiko-Cindar-Flarex",1,"Rare",false,false,"Flarex",36,88,94,58,76,63);
        add("Flarex","Fire","Burst Attacker",3,"Tiko-Cindar-Flarex",1,"Epic",false,false,null,0,119,128,77,98,86);

        add("Nero","Water","Tank",1,"Nero-Torran-Abyssor",1,"Rare",true,false,"Torran",16,78,50,66,42,60);
        add("Torran","Water","Tank",2,"Nero-Torran-Abyssor",1,"Rare",false,false,"Abyssor",36,105,72,88,58,78);
        add("Abyssor","Water","Tank",3,"Nero-Torran-Abyssor",1,"Epic",false,false,null,0,145,96,116,76,105);

        add("Kairo","Grass","Control",1,"Kairo-Thornix-Virdan",1,"Rare",true,false,"Thornix",16,70,56,58,50,64);
        add("Thornix","Grass","Control",2,"Kairo-Thornix-Virdan",1,"Rare",false,false,"Virdan",36,95,76,80,67,86);
        add("Virdan","Grass","Control",3,"Kairo-Thornix-Virdan",1,"Epic",false,false,null,0,128,100,105,89,112);

        String[] prefixes = {"Zar","Vey","Rav","Nox","Kair","Vyr","Or","Zen","Kiro","Torr","Aby","Cind","Flare","Barq","Raq","Mez","Sahr","Noor","Zehr","Koh","Lehr","Aat","Mauj","Dum","Qir","Vant","Skyr","Sol","Mar","Ryn","Kael","Dro","Siv","Nair","Vel","Ash","Bryn","Taz","Kest","Mir","Dary","Rook","Jal","Saff","Rift","Zain","Nim","Raz","Ory","Tuf","Gard","Nyx","Caro","Ish","Mek","Rune","Halo"};
        String[] suffixes = {"o","ix","or","an","el","ar","en","on","ra","is","yr","ak","in","os","um","ex","al","ai","eth","orn","ven","zor","lin","var","mir","dor","ash","ion","yx","eer","aan","rek","vex","lor","ari","avo"};
        String[] types = {"Electric","Fire","Water","Grass","Earth","Air","Steel","Dark","Light","Psychic","Ice","Poison","Fighting","Rock","Smoke"};
        String[] roles = {"Speed Attacker","Burst Attacker","Tank","Control","Support","Bruiser","Trickster","Sweeper","Guardian","Assassin"};
        HashSet<String> used = new HashSet<>();
        for (Creature c : dex) used.add(c.name);

        int idTarget = 1024;
        int index = 0;
        while (dex.size() < idTarget) {
            String p = prefixes[(index * 7 + 3) % prefixes.length];
            String s = suffixes[(index * 11 + 5) % suffixes.length];
            String base = cap(p + s);
            if (used.contains(base)) { index++; continue; }
            String type = types[(index * 5 + 2) % types.length];
            String role = roles[(index * 3 + 1) % roles.length];
            int phase = dex.size() < 150 ? 1 : dex.size() < 350 ? 2 : dex.size() < 600 ? 3 : dex.size() < 850 ? 4 : 5;
            boolean locked = phase >= 2;
            String rarity = phase == 1 ? "Common" : phase == 2 ? "Uncommon" : phase == 3 ? "Rare" : phase == 4 ? "Epic" : "Legendary";
            int stage = 1;
            String line = base;
            int hp = 58 + (index % 34) + phase * 7;
            int atk = 44 + ((index*3) % 42) + phase * 4;
            int def = 39 + ((index*5) % 38) + phase * 4;
            int speed = 37 + ((index*7) % 45) + phase * 3;
            int spirit = 36 + ((index*9) % 39) + phase * 3;
            add(base, type, role, stage, line, phase, rarity, false, locked, null, 0, hp, atk, def, speed, spirit);
            used.add(base);
            index++;
        }
    }

    String cap(String s) {
        if (s.length() == 0) return s;
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }

    void add(String name,String type,String role,int stage,String line,int phase,String rarity,boolean starter,boolean locked,String evolvesTo,int evolveLevel,int hp,int atk,int def,int speed,int spirit) {
        dex.add(new Creature(dex.size()+1, name, type, role, stage, line, phase, rarity, starter, locked, evolvesTo, evolveLevel, hp, atk, def, speed, spirit, movesFor(type), weakAgainst(type), strongAgainst(type)));
    }

    public class ArenaView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public ArenaView(android.content.Context c){ super(c); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(31,47,89),Color.rgb(8,12,23),Shader.TileMode.CLAMP));
            c.drawRoundRect(0,0,w,h,dp(22),dp(22),p); p.setShader(null);
            p.setColor(Color.rgb(47,64,110));
            c.drawOval(dp(30),dp(70),w-dp(30),h-dp(20),p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(3)); p.setColor(Color.rgb(94,130,255));
            c.drawOval(dp(55),dp(90),w-dp(55),h-dp(40),p); p.setStyle(Paint.Style.FILL);
            drawOrb(c, w/3, h/2, "Electric");
            drawOrb(c, w*2/3, h/2, "Fire");
        }
        void drawOrb(Canvas c,int x,int y,String type){
            p.setColor(colorFor(type)); c.drawCircle(x,y,dp(38),p);
            p.setColor(Color.argb(180,255,255,255)); c.drawCircle(x-dp(12),y-dp(13),dp(10),p);
            p.setColor(Color.rgb(8,12,23)); c.drawCircle(x+dp(11),y-dp(2),dp(6),p); c.drawCircle(x-dp(13),y-dp(2),dp(6),p);
        }
    }

    public class BattleView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public BattleView(android.content.Context c){ super(c); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setColor(Color.rgb(17,24,44)); c.drawRoundRect(0,0,w,h,dp(22),dp(22),p);
            p.setColor(Color.rgb(45,56,96)); c.drawOval(dp(22),h-dp(80),w-dp(22),h-dp(15),p);
            Creature me = team.isEmpty()? null : creature(team.get(0));
            if(me!=null) drawMonster(c,w/3,h/2,me.type);
            if(enemy!=null) drawMonster(c,w*2/3,h/2,enemy.type);
            p.setColor(GOLD); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(dp(18)); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText("VS", w/2, h/2, p);
        }
        void drawMonster(Canvas c,int x,int y,String type){
            p.setColor(colorFor(type)); c.drawCircle(x,y,dp(42),p);
            p.setColor(Color.argb(190,255,255,255)); c.drawCircle(x-dp(14),y-dp(16),dp(11),p);
            p.setColor(Color.rgb(8,12,23)); c.drawCircle(x+dp(12),y-dp(4),dp(6),p); c.drawCircle(x-dp(14),y-dp(4),dp(6),p);
        }
    }

    public class CreatureIcon extends View {
        String type; Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public CreatureIcon(android.content.Context c, String type){ super(c); this.type=type; }
        @Override protected void onDraw(Canvas c){
            int w=getWidth(), h=getHeight();
            p.setColor(colorFor(type)); c.drawCircle(w/2,h/2,Math.min(w,h)/2 - dp(4),p);
            p.setColor(Color.argb(180,255,255,255)); c.drawCircle(w/2-dp(12),h/2-dp(14),dp(10),p);
            p.setColor(Color.rgb(8,12,23)); c.drawCircle(w/2+dp(12),h/2-dp(3),dp(5),p); c.drawCircle(w/2-dp(12),h/2-dp(3),dp(5),p);
        }
    }

    int colorFor(String type){
        switch(type){
            case "Electric": return Color.rgb(255,209,45);
            case "Fire": return Color.rgb(255,105,61);
            case "Water": return Color.rgb(42,152,255);
            case "Grass": return Color.rgb(76,211,106);
            case "Earth": return Color.rgb(155,113,67);
            case "Air": return Color.rgb(154,223,246);
            case "Steel": return Color.rgb(170,179,196);
            case "Dark": return Color.rgb(41,36,56);
            case "Light": return Color.rgb(255,233,137);
            case "Psychic": return Color.rgb(195,108,255);
            case "Ice": return Color.rgb(149,232,255);
            case "Poison": return Color.rgb(158,76,210);
            case "Fighting": return Color.rgb(191,86,66);
            case "Rock": return Color.rgb(138,122,101);
            default: return Color.rgb(107,114,128);
        }
    }
}
